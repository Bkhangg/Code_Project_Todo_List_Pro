<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">📄 Chi tiết công việc</h5>
                <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-sm btn-secondary">⬅ Quay lại</a>
            </div>
            <div class="card-body">
                <h4 class="fw-bold mb-3"><?php echo e($task->title); ?></h4>
                <p class="text-muted"><strong>Mô tả:</strong></p>
                <p><?php echo e($task->description); ?></p>
                <p><strong>Hạn chót:</strong> <span class="badge bg-danger"><?php echo e($task->due_date ? $task->due_date : 'Chưa thêm date'); ?></span></p>
                <p><strong>Trạng thái:</strong> <td>
                        <?php switch($task->status):
                            case (0): ?>
                                <span class="badge bg-primary">Đang bắt đầu</span>
                                <?php break; ?>
                            <?php case (1): ?>
                                <span class="badge bg-warning">Đang Làm</span>
                                <?php break; ?>
                            <?php case (2): ?>
                                <span class="badge bg-success">Hoàn thành</span>
                                <?php break; ?>
                            <?php default: ?>
                                <span class="badge bg-primary">Đang bắt đầu</span>
                                <?php break; ?>
                        <?php endswitch; ?>
                    </td></p>

                <div class="mt-4 d-flex justify-content-end">
                    <a href="<?php echo e(route('tasks.edit', 1)); ?>" class="btn btn-warning me-2">✏️ Sửa</a>
                    <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="POST" onsubmit="return confirm('Bạn có chắc chắn muốn xoá công việc này?');" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">🗑 Xoá</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tasks.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\todo-list-pro\resources\views/tasks/show.blade.php ENDPATH**/ ?>