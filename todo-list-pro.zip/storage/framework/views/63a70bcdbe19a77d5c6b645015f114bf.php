<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Danh sách công việc</h5>
        <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-sm btn-primary">+ Thêm Task</a>
    </div>
    <div class="card-body">
        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Công việc</th>
                    <th>Hạn chót</th>
                    <th>Trạng thái</th>
                    <th>Thời gian</th>
                    <th>Người tạo</th>
                    <th class="text-end">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <!-- Demo static -->
                <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($task->id); ?></td>
                    <td><?php echo e($task->title); ?></td>
                    <td><?php echo e($task->due_date ? $task->due_date : 'Chưa thêm date'); ?></td>
                    <td>
                        <?php switch($task->status):
                            case (0): ?>
                                <span class="badge bg-primary">Đang bắt đầu</span>
                                <?php break; ?>
                            <?php case (1): ?>
                                <span class="badge bg-warning">Đang Làm</span>
                                <?php break; ?>
                            <?php case (2): ?>
                                <span class="badge bg-success">Hoàn thành</span>
                                <?php break; ?>
                            <?php default: ?>
                                <span class="badge bg-primary">Đang bắt đầu</span>
                                <?php break; ?>
                        <?php endswitch; ?>
                    </td>
                    <td>
                        <?php echo e($task->created_at->format('Y-m-d')); ?>

                    </td>
                    <td>
                        <?php echo e($task->user->name); ?>

                    </td>
                    <td class="text-end">
                        <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-sm btn-info text-white">Xem</a>
                        <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-sm btn-warning">Sửa</a>
                        <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="POST" onsubmit="return confirm('Bạn có chắc chắn muốn xoá công việc này?');" style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">🗑 Xoá</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <td class="text-center" colspan="7">Không có tasks nào trong đây.</td>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="center">
            <?php echo e($tasks->links('')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tasks.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\todo-list-pro\resources\views/tasks/index.blade.php ENDPATH**/ ?>